#!/usr/bin/env python3

from flexbe_core import EventState, Logger
from flexbe_core.proxy import ProxySubscriberCached

from sensor_msgs.msg import Image, CameraInfo
from geometry_msgs.msg import PointStamped
from cv_bridge import CvBridge
import numpy as np
import tf2_ros
import tf2_geometry_msgs
import rclpy

# Don't import cv2 at module level - delay until needed


class ArucoDetectionState(EventState):
    """
    FlexBE state for detecting ArUco markers and getting their 3D position from base_link.
    
    Detects ArUco markers using RGB-D camera and computes their position in base_link frame.
    
    Parameters:
    -- target_id        int     Target ArUco marker ID to detect (use -1 for any marker, default: -1)
    -- timeout          float   Timeout in seconds (default: 10.0)
    
    Outcomes:
    <= detected         ArUco marker detected successfully
    <= timeout          Timeout reached without detection
    <= failed           Detection failed
    
    Output Keys:
    #> marker_id        Detected marker ID
    #> marker_x         X position in base_link frame (meters)
    #> marker_y         Y position in base_link frame (meters)
    #> marker_z         Z position in base_link frame (meters)
    #> camera_x         X position in camera frame (meters)
    #> camera_y         Y position in camera frame (meters)
    #> camera_z         Z position in camera frame (meters)
    #> pixel_x          Pixel X coordinate in image
    #> pixel_y          Pixel Y coordinate in image
    """

    def __init__(self, target_id=-1, timeout=10.0):
        super(ArucoDetectionState, self).__init__(
            outcomes=['detected', 'timeout', 'failed'],
            output_keys=['marker_id', 'marker_x', 'marker_y', 'marker_z',
                        'camera_x', 'camera_y', 'camera_z',
                        'pixel_x', 'pixel_y']
        )
        
        # Parameters
        self._target_id = target_id
        self._timeout = timeout
        
        # CV Bridge
        self._bridge = CvBridge()
        
        # ArUco detector (will be initialized lazily)
        self._aruco_dict = None
        self._aruco_params = None
        self._detector = None
        self._cv2_initialized = False
        self._use_legacy_api = False
        
        # Topic names
        self._rgb_topic = '/camera/color/image_raw'
        self._depth_topic = '/camera/depth/image_raw'
        self._camera_info_topic = '/camera/color/camera_info'
        
        # Subscribers
        self._rgb_sub = ProxySubscriberCached({self._rgb_topic: Image})
        self._depth_sub = ProxySubscriberCached({self._depth_topic: Image})
        self._camera_info_sub = ProxySubscriberCached({self._camera_info_topic: CameraInfo})
        
        # TF2 for transformations
        self._tf_buffer = None
        self._tf_listener = None
        
        # Camera intrinsics (will be loaded from camera_info)
        self._fx = None
        self._fy = None
        self._cx = None
        self._cy = None
        
        # State management
        self._start_time = None
        self._return = None

    def execute(self, userdata):
        """Execute state - called periodically while state is active."""
        if self._return is not None:
            return self._return
        
        # Initialize cv2 on first execute call (not during preparation)
        if not self._cv2_initialized:
            if not self._initialize_cv2():
                self._return = 'failed'
                return 'failed'
        
        # Check timeout
        elapsed = ArucoDetectionState._node.get_clock().now() - self._start_time
        elapsed_sec = elapsed.nanoseconds / 1e9
        
        if elapsed_sec >= self._timeout:
            Logger.logwarn(f'ArUco detection timeout after {elapsed_sec:.1f}s')
            self._return = 'timeout'
            return 'timeout'
        
        # Load camera info if not yet loaded
        if self._fx is None:
            self._load_camera_info()
        
        # Try to detect marker
        detection = self._detect_aruco()
        
        if detection:
            # Marker detected!
            marker_id, pixel_x, pixel_y, depth = detection
            
            # Compute 3D position in camera frame
            camera_x, camera_y, camera_z = self._pixel_to_camera_coords(pixel_x, pixel_y, depth)
            
            if camera_x is None:
                Logger.logwarn('Failed to compute camera coordinates')
                return None
            
            Logger.loginfo(f'Marker {marker_id} at camera frame: ({camera_x:.3f}, {camera_y:.3f}, {camera_z:.3f})')
            
            # Transform to base_link frame
            base_x, base_y, base_z = self._transform_to_base_link(camera_x, camera_y, camera_z)
            
            if base_x is not None:
                Logger.loginfo(f'Marker {marker_id} in base_link: ({base_x:.3f}, {base_y:.3f}, {base_z:.3f})')
                
                # Fill output userdata
                userdata.marker_id = marker_id
                userdata.marker_x = base_x
                userdata.marker_y = base_y
                userdata.marker_z = base_z
                userdata.camera_x = camera_x
                userdata.camera_y = camera_y
                userdata.camera_z = camera_z
                userdata.pixel_x = pixel_x
                userdata.pixel_y = pixel_y
                
                self._return = 'detected'
                return 'detected'
            else:
                Logger.logwarn('Failed to transform to base_link')
        
        return None

    def on_enter(self, userdata):
        """Called when state becomes active."""
        self._return = None
        self._fx = None
        self._fy = None
        self._cx = None
        self._cy = None
        
        # Initialize TF2
        self._tf_buffer = tf2_ros.Buffer()
        self._tf_listener = tf2_ros.TransformListener(self._tf_buffer, ArucoDetectionState._node)
        
        self._start_time = ArucoDetectionState._node.get_clock().now()
        
        if self._target_id >= 0:
            Logger.loginfo(f'Searching for ArUco marker ID {self._target_id}...')
        else:
            Logger.loginfo('Searching for any ArUco marker...')

    def on_exit(self, userdata):
        """Called when leaving the state."""
        Logger.loginfo('ArucoDetection state exiting')

    def on_start(self):
        """Called when behavior starts."""
        Logger.loginfo('ArucoDetection state started')

    def on_stop(self):
        """Called when behavior stops."""
        Logger.loginfo('ArucoDetection state stopped')

    # ==================== Helper Methods ====================

    def _initialize_cv2(self):
        """Initialize cv2 and ArUco detector. Called during execute, not preparation."""
        try:
            import cv2
            
            Logger.loginfo(f'OpenCV version: {cv2.__version__}')
            
            # Try new API first (OpenCV 4.7+)
            try:
                self._aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
                self._aruco_params = cv2.aruco.DetectorParameters()
                self._detector = cv2.aruco.ArucoDetector(self._aruco_dict, self._aruco_params)
                self._use_legacy_api = False
                Logger.loginfo('ArUco detector initialized (NEW API)')
                
            except AttributeError:
                # Fall back to legacy API (OpenCV 3.x - 4.6)
                self._aruco_dict = cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_50)
                self._aruco_params = cv2.aruco.DetectorParameters_create()
                self._use_legacy_api = True
                Logger.loginfo('ArUco detector initialized (LEGACY API)')
            
            self._cv2_initialized = True
            return True
            
        except Exception as e:
            Logger.logerr(f'Failed to initialize ArUco detector: {str(e)}')
            import traceback
            traceback.print_exc()
            return False

    def _load_camera_info(self):
        """Load camera intrinsics from camera_info topic."""
        if not self._camera_info_sub.has_msg(self._camera_info_topic):
            return False
        
        try:
            camera_info = self._camera_info_sub.get_last_msg(self._camera_info_topic)
            
            self._fx = camera_info.k[0]  # focal length x
            self._fy = camera_info.k[4]  # focal length y
            self._cx = camera_info.k[2]  # principal point x
            self._cy = camera_info.k[5]  # principal point y
            
            Logger.loginfo(f'Camera info loaded: fx={self._fx:.1f}, fy={self._fy:.1f}, cx={self._cx:.1f}, cy={self._cy:.1f}')
            return True
            
        except Exception as e:
            Logger.logerr(f'Error loading camera info: {str(e)}')
            return False

    def _detect_aruco(self):
        """
        Detect ArUco marker in RGB-D images.
        Returns: (marker_id, pixel_x, pixel_y, depth_meters) or None
        """
        # Check if we have both RGB and depth images
        if not self._rgb_sub.has_msg(self._rgb_topic):
            return None
        
        if not self._depth_sub.has_msg(self._depth_topic):
            return None
        
        if not self._cv2_initialized:
            return None
        
        try:
            import cv2
            
            # Get RGB image
            rgb_msg = self._rgb_sub.get_last_msg(self._rgb_topic)
            cv_image = self._bridge.imgmsg_to_cv2(rgb_msg, desired_encoding='bgr8')
            
            # Get depth image
            depth_msg = self._depth_sub.get_last_msg(self._depth_topic)
            depth_image = self._bridge.imgmsg_to_cv2(depth_msg, desired_encoding='passthrough')
            
            # Detect ArUco markers using appropriate API
            if self._use_legacy_api:
                # Legacy API (OpenCV 3.x - 4.6)
                corners, ids, rejected = cv2.aruco.detectMarkers(
                    cv_image, 
                    self._aruco_dict, 
                    parameters=self._aruco_params
                )
            else:
                # New API (OpenCV 4.7+)
                corners, ids, rejected = self._detector.detectMarkers(cv_image)
            
            if ids is None:
                return None
            
            # Get image dimensions
            rgb_height, rgb_width = cv_image.shape[:2]
            depth_height, depth_width = depth_image.shape[:2]
            
            # Process each detected marker
            for i, marker_id in enumerate(ids):
                marker_id = int(marker_id[0])
                
                # Check if this is the target marker (or any if target_id < 0)
                if self._target_id >= 0 and marker_id != self._target_id:
                    continue
                
                # Get center of marker in RGB coordinates
                center_x_rgb = int(np.mean(corners[i][0][:, 0]))
                center_y_rgb = int(np.mean(corners[i][0][:, 1]))
                
                # Scale to depth image size
                center_x_depth = int(center_x_rgb * depth_width / rgb_width)
                center_y_depth = int(center_y_rgb * depth_height / rgb_height)
                
                # Get depth at marker center
                if 0 <= center_y_depth < depth_height and 0 <= center_x_depth < depth_width:
                    # Sample 5x5 region for stability
                    y_start = max(0, center_y_depth - 2)
                    y_end = min(depth_height, center_y_depth + 3)
                    x_start = max(0, center_x_depth - 2)
                    x_end = min(depth_width, center_x_depth + 3)
                    
                    depth_region = depth_image[y_start:y_end, x_start:x_end]
                    
                    # Remove invalid depths and average
                    valid_depths = depth_region[depth_region > 0]
                    
                    if len(valid_depths) > 0:
                        depth_value = np.mean(valid_depths)
                        depth_meters = float(depth_value) / 1000.0  # Convert to meters
                        
                        Logger.loginfo(f'Detected marker {marker_id} at pixel ({center_x_rgb}, {center_y_rgb}), depth={depth_meters:.3f}m')
                        
                        return (marker_id, center_x_rgb, center_y_rgb, depth_meters)
            
            return None
            
        except Exception as e:
            Logger.logerr(f'Error in ArUco detection: {str(e)}')
            import traceback
            traceback.print_exc()
            return None

    def _pixel_to_camera_coords(self, pixel_x, pixel_y, depth):
        """
        Convert pixel coordinates + depth to 3D coordinates in camera frame.
        Uses pinhole camera model with actual camera intrinsics.
        """
        if self._fx is None or self._fy is None or self._cx is None or self._cy is None:
            Logger.logwarn('Camera intrinsics not loaded yet')
            return None, None, None
        
        # Camera coordinate system (RealSense camera_color_frame):
        # X: right, Y: down, Z: forward
        camera_x = (pixel_x - self._cx) * depth / self._fx
        camera_y = (pixel_y - self._cy) * depth / self._fy
        camera_z = depth
        
        return camera_x, camera_y, camera_z

    def _transform_to_base_link(self, camera_x, camera_y, camera_z):
        """
        Transform coordinates from camera_color_frame to base_link using TF2.
        Returns: (base_x, base_y, base_z) or (None, None, None) if failed
        """
        try:
            # Create PointStamped in camera frame
            point_camera = PointStamped()
            point_camera.header.frame_id = 'camera_color_frame'
            point_camera.header.stamp = ArucoDetectionState._node.get_clock().now().to_msg()
            point_camera.point.x = camera_x
            point_camera.point.y = camera_y
            point_camera.point.z = camera_z
            
            # Get transform from camera_color_frame to base_link
            transform = self._tf_buffer.lookup_transform(
                'base_link',
                'camera_color_frame',
                rclpy.time.Time(),
                timeout=rclpy.duration.Duration(seconds=1.0)
            )
            
            # Apply transformation using tf2_geometry_msgs
            point_base = tf2_geometry_msgs.do_transform_point(point_camera, transform)
            
            return float(point_base.point.x), float(point_base.point.y), float(point_base.point.z)
            
        except Exception as e:
            Logger.logerr(f'TF transform failed: {str(e)}')
            return None, None, None